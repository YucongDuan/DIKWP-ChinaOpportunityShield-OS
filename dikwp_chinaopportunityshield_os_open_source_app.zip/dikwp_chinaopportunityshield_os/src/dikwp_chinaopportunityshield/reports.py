from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import List

from .models import PortfolioAssessment, RepoAssessment, to_dict


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: List[dict], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fields})


def render_protection_plan(a: PortfolioAssessment) -> str:
    lines = [
        "# DIKWP ChinaOpportunityShield Protection Action Plan",
        "",
        f"Owner: **{a.owner}**",
        f"Portfolio score: **{a.portfolio_score}**",
        f"Recommended strategy: **{a.recommended_strategy}**",
        "",
        "## 1. Strategic Diagnosis",
        "",
        "The portfolio already contains many DIKWP application prototypes. The immediate risk is not absence of projects but **opportunity leakage**: external organizations can reuse repository ideas, remove attribution, request private templates, or turn public reference code into commercial packaging without returning value to the originator.",
        "",
        "The protection strategy is therefore not code secrecy. It is **registry-led open source**: open enough to attract pilots, but keep official review, signed badges, industry adapter packs, certification, and pilot reports as controlled value layers.",
        "",
        "## 2. Mandatory Protection Moves",
        "",
        "1. Every active DIKWP repository should contain README, LICENSE, NOTICE, CITATION.cff, SECURITY, and TrustPassport metadata.",
        "2. Each public pilot conversation should enter an Opportunity Ledger before materials are shared.",
        "3. Private assets must be classified: issuer keys, official registry decisions, full industry templates, enterprise deployment playbooks, and partner contracts are controlled assets.",
        "4. Public deliverables should be reference implementations, schemas, demos, sample data, tests, and open evaluation logic.",
        "5. Paid layers should be official DIKWP review, China pilot scoping, industry adaptation, training certification, and signed registry badge issuance.",
        "",
        "## 3. Priority Repositories",
        "",
    ]
    for r in sorted(a.repo_assessments, key=lambda x: x.commercialization_score, reverse=True)[:12]:
        lines.append(f"- **{r.name}** — lane: `{r.lane}`, commercialization: `{r.commercialization_score}`, protection need: `{r.protection_need_score}`, action: `{r.recommended_action}`")
    lines += [
        "",
        "## 4. Partner Handling Rules",
        "",
        "- Do not send full source, private templates, official registry files, or issuer keys before attribution and scope terms are written.",
        "- For government, transport, manufacturing, medical, education, and finance opportunities, start with a paid discovery or low-risk offline pilot.",
        "- Copycat-like actors should first receive public docs and a partner conversion path, not escalation language.",
        "- If a partner requests exclusive rights, patent transfer, or full source ownership, route to OriginMoat/IPGuardian review before any technical sharing.",
        "",
        "## 5. 30/60/90-Day Actions",
        "",
        "### 30 days",
        "- Pick 6 public flagship repos and standardize READMEs, badges, quick-start demos, and Mandarin product briefs.",
        "- Publish a DIKWP China Pilot Menu that routes enterprises to 5 paid pilot types.",
        "- Create a public registry seed: project name, claim boundary, owner attribution, status, and official review pathway.",
        "",
        "### 60 days",
        "- Run 3 small offline pilots: transport/service, enterprise evidence ledger, and public-benefit AI governance.",
        "- Add signed pilot report templates and partner intake forms.",
        "- Invite integrators as registered partner candidates rather than giving them unbounded reuse rights.",
        "",
        "### 90 days",
        "- Launch official DIKWP TrustPassport China Registry v0.1.",
        "- Release training certification syllabus: DIKWP Pilot Analyst, DIKWP Evidence Steward, DIKWP OpenClaw Operator.",
        "- Publish anonymized case reports and collect inbound paid pilot leads.",
        "",
        "## 6. Kill / Recovery",
        "",
        "Kill conditions: missing attribution, partner demands exclusive rights, hidden commercial packaging, official certification claims without review, private templates requested before agreement, or sensitive data exposure.",
        "",
        "Recovery: downgrade sharing to public brief, require attribution clause, create opportunity ledger entry, route to paid discovery, and preserve official registry/certification as controlled value layer.",
    ]
    return "\n".join(lines)


def render_90_day_plan(a: PortfolioAssessment) -> str:
    lines = [
        "# DIKWP ChinaOpportunityShield 90-Day Action Plan",
        "",
        "## Week 1-2: Clean Public Surface",
        "- Select flagship repos: ProofLedger, OpenClaw, SemanticClosure, TaskRide, BusPulse/TransitVoice, ScholarTruth, TrustPassport.",
        "- Ensure README / LICENSE / NOTICE / CITATION.cff / SECURITY are present.",
        "- Add project one-liner, action boundary, quick start, demo outputs, and Chinese product brief.",
        "",
        "## Week 3-4: Launch China Pilot Menu",
        "- Publish 5 pilot packages: AI evidence ledger, public transport service closure, enterprise agent audit, DeepSeek OpenClaw, academic integrity triage.",
        "- Each pilot has scope, inputs, outputs, timeline, price band, and non-claim boundary.",
        "",
        "## Month 2: Convert Leads",
        "- Use PilotFactory logic: inbound lead -> opportunity ledger -> paid discovery -> pilot SOW -> official review report.",
        "- Use TrustPassport for registry candidate IDs.",
        "- Use IPGuardian for copycat / no-attribution monitoring.",
        "",
        "## Month 3: Public Credibility",
        "- Publish 2 anonymized case studies.",
        "- Publish DIKWP China TrustOS map.",
        "- Invite universities / associations / integrators as registered partner candidates.",
        "- Keep industry templates, signed badges, and official reviews as value layers.",
    ]
    return "\n".join(lines)


def render_benefit_brief(a: PortfolioAssessment) -> str:
    return f"""# Benefit Capture Brief for Yucong Duan / DIKWP

## Core Position
Yucong Duan's public GitHub portfolio should be positioned in China as **DIKWP TrustOS**: a semantic-intelligence trust, evidence, intent, and opportunity-governance ecosystem.

## What to Open
- Reference implementations
- Public schemas
- Demo data
- Offline CLIs
- Evidence-ledger examples
- Conformance tests

## What to Protect
- Official registry decisions
- Signed TrustPassport badges
- Industry adapter packs
- Partner contracts
- Certification exams
- Official pilot review reports
- Issuer keys and private templates

## Economic Path
1. Open-source attention -> inbound lead.
2. Lead -> Opportunity Ledger.
3. Opportunity Ledger -> paid discovery.
4. Paid discovery -> pilot SOW.
5. Pilot -> official DIKWP review report.
6. Review report -> TrustPassport registry + training + partner expansion.

## Reputation Path
The public story should emphasize: DIKWP is not one tool. It is a China-ready semantic governance stack connecting Data, Information, Knowledge, Wisdom, and Purpose under noisy, incomplete, inconsistent real-world conditions.

## Current Portfolio Score
Portfolio score: {a.portfolio_score}
Recommended strategy: {a.recommended_strategy}
"""


def render_registry_seed(a: PortfolioAssessment) -> list:
    seed = []
    for r in a.repo_assessments:
        seed.append({
            "project": r.name,
            "lane": r.lane,
            "registry_status": "candidate",
            "recommended_open_core_tier": r.open_core_tier,
            "official_claim_boundary": "reference implementation; official certification requires DIKWP review",
            "attribution_required": True,
        })
    return seed


def write_outputs(out_dir: Path, assessment: PortfolioAssessment) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "github_portfolio_assessment.json", to_dict(assessment))

    repo_rows = [to_dict(r) for r in assessment.repo_assessments]
    write_csv(out_dir / "repo_lane_map.csv", repo_rows, ["name", "lane", "china_opportunity_score", "protection_need_score", "commercialization_score", "open_core_tier", "recommended_action"])
    write_csv(out_dir / "china_opportunity_matrix.csv", repo_rows, ["name", "lane", "china_opportunity_score", "commercialization_score", "recommended_action"])
    write_csv(out_dir / "open_core_release_policy.csv", repo_rows, ["name", "open_core_tier", "protection_need_score", "recommended_action"])

    partner_rows = [to_dict(p) for p in assessment.partner_decisions]
    write_csv(out_dir / "partner_screening_report.csv", partner_rows, ["organization", "decision", "score", "next_step"])
    write_json(out_dir / "partner_screening_report.json", partner_rows)
    write_json(out_dir / "official_registry_seed.json", render_registry_seed(assessment))
    write_json(out_dir / "opportunity_ledger.json", {
        "owner": assessment.owner,
        "ledger_status": "seed",
        "required_fields": ["date", "partner", "sector", "source", "requested_assets", "attribution_terms", "data_boundary", "next_step", "risk", "owner_action"],
        "entries": [to_dict(p) for p in assessment.partner_decisions],
    })
    (out_dir / "protection_action_plan.md").write_text(render_protection_plan(assessment), encoding="utf-8")
    (out_dir / "priority_90_day_action_plan.md").write_text(render_90_day_plan(assessment), encoding="utf-8")
    (out_dir / "benefit_capture_brief.md").write_text(render_benefit_brief(assessment), encoding="utf-8")
