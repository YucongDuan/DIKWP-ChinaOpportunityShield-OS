from __future__ import annotations

import re
from typing import Iterable


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


def contains_any(text: str, terms: Iterable[str]) -> bool:
    t = normalize(text)
    return any(term.lower() in t for term in terms)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def safe_id(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "-", text).strip("-")[:80] or "item"
