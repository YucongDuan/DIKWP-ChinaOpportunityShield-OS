from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

from .models import Portfolio, Repository, PartnerRequest, RepoAssessment, PartnerDecision, PortfolioAssessment
from .text_utils import contains_any, normalize, clamp

LANE_RULES: Dict[str, List[str]] = {
    "ai_trust_evidence": ["proofledger", "agenttrace", "semchain", "audit", "evidence", "trust", "trace", "ledger"],
    "china_industrial_ai": ["aicap", "buspulse", "transit", "mobility", "gateway", "manufacturing", "industrial", "hardware", "bus", "transport"],
    "public_wellbeing": ["welfare", "capability", "workbridge", "activehealth", "mindguardian", "learnpath", "education", "health", "social"],
    "medical_research": ["hepato", "onco", "medical", "liver", "oncology", "research", "evidence"],
    "consumer_ai_tools": ["truthsnap", "openclaw", "longxia", "pocket", "deepseek", "semantic capsule"],
    "ip_standardization": ["ipguardian", "standardforge", "scholartruth", "triz", "translation", "patent", "standard"],
    "ac_research": ["acrs", "consciousness", "internalmax", "primalquestions", "semantic genesis", "null-field"],
    "commercial_conversion": ["pilotfactory", "answergraph", "intenteconomy", "taskride", "marketplace", "commerce", "seo"],
}

LANE_BASE_OPPORTUNITY = {
    "ai_trust_evidence": 0.85,
    "china_industrial_ai": 0.92,
    "public_wellbeing": 0.80,
    "medical_research": 0.78,
    "consumer_ai_tools": 0.82,
    "ip_standardization": 0.88,
    "ac_research": 0.62,
    "commercial_conversion": 0.90,
    "general_dikwp": 0.55,
}

LANE_PROTECTION_NEED = {
    "ai_trust_evidence": 0.76,
    "china_industrial_ai": 0.86,
    "public_wellbeing": 0.70,
    "medical_research": 0.74,
    "consumer_ai_tools": 0.82,
    "ip_standardization": 0.95,
    "ac_research": 0.90,
    "commercial_conversion": 0.88,
    "general_dikwp": 0.60,
}


def load_portfolio(path: str | Path) -> Portfolio:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    repos = [Repository(**r) for r in raw.get("repositories", [])]
    partners = [PartnerRequest(**p) for p in raw.get("partner_requests", [])]
    return Portfolio(
        owner=raw.get("owner", "unknown"),
        profile_url=raw.get("profile_url", ""),
        snapshot_date=raw.get("snapshot_date", ""),
        repositories=repos,
        partner_requests=partners,
    )


def classify_lane(repo: Repository) -> str:
    text = " ".join([repo.name, repo.description, " ".join(repo.topics)])
    scores = {lane: sum(1 for term in terms if term.lower() in normalize(text)) for lane, terms in LANE_RULES.items()}
    lane, score = max(scores.items(), key=lambda kv: kv[1])
    return lane if score > 0 else "general_dikwp"


def assess_repo(repo: Repository) -> RepoAssessment:
    lane = classify_lane(repo)
    desc = normalize(repo.description)
    has_license = bool(repo.license)
    has_attribution_signal = contains_any(repo.name + " " + repo.description, ["dikwp", "yucong", "duan"])
    has_os_signal = contains_any(repo.description, ["open-source", "offline", "github-ready", "reference system", "prototype"])
    stars_factor = min(repo.stars, 20) / 20.0

    base = LANE_BASE_OPPORTUNITY[lane]
    opportunity = clamp(base * 0.72 + (0.08 if has_os_signal else 0.0) + 0.08 * stars_factor + (0.05 if has_license else 0.0))
    protection = clamp(LANE_PROTECTION_NEED[lane] * 0.72 + (0.12 if not has_attribution_signal else 0.03) + (0.08 if lane in {"ip_standardization", "china_industrial_ai", "commercial_conversion"} else 0.0))
    commercialization = clamp((opportunity * 0.55) + (protection * 0.20) + (0.18 if lane in {"china_industrial_ai", "commercial_conversion", "ip_standardization", "ai_trust_evidence"} else 0.08))

    if protection >= 0.82 and commercialization >= 0.70:
        tier = "open_validator_keep_registry_certification_templates_private"
    elif protection >= 0.75:
        tier = "open_reference_core_keep_industry_adapter_pack_official"
    elif commercialization >= 0.70:
        tier = "open_core_monetize_training_pilot_review"
    else:
        tier = "fully_open_community_entry"

    if commercialization >= 0.78:
        action = "promote_as_china_paid_pilot_candidate"
    elif protection >= 0.84:
        action = "add_trustpassport_originmoat_and_official_registry_before_wide_promotion"
    elif opportunity >= 0.70:
        action = "publish_with_case_study_and_partner_call"
    else:
        action = "keep_as_ecosystem_supporting_project"

    evidence = [
        f"lane={lane}",
        f"has_license={has_license}",
        f"has_attribution_signal={has_attribution_signal}",
        f"has_open_source_signal={has_os_signal}",
    ]
    residuals = []
    if not has_license:
        residuals.append("license not visible in supplied manifest; verify repository page before commercial outreach")
    if not has_attribution_signal:
        residuals.append("DIKWP/Yucong attribution not visible in name/description; strengthen NOTICE/CITATION/README")
    return RepoAssessment(repo.name, lane, round(opportunity, 4), round(protection, 4), round(commercialization, 4), tier, action, evidence, residuals)


def score_partner(p: PartnerRequest) -> PartnerDecision:
    risks: List[str] = []
    required_terms = [
        "DIKWP/Yucong Duan attribution clause",
        "pilot scope boundary and non-exclusive rights",
        "no public official-certification claim without signed review",
        "evidence ledger and meeting record",
    ]
    text = normalize(" ".join([p.organization, p.sector, p.stated_need, " ".join(p.requested_assets), " ".join(p.requested_rights)]))
    high_fit = contains_any(text, ["manufacturing", "工业", "bus", "交通", "hospital", "医疗", "government", "政务", "education", "学校", "能源", "agent", "智能体"])
    budget = normalize(p.budget_signal)
    attribution_ok = normalize(p.attribution_commitment) in {"yes", "explicit", "strong", "will_cite", "signed"}
    sensitive = normalize(p.data_sensitivity) in {"high", "sensitive", "critical", "medical", "finance", "personal"}
    exclusive = contains_any(" ".join(p.requested_rights), ["exclusive", "buyout", "source ownership", "transfer patent", "独占", "买断", "转让专利"])
    asks_full_core = contains_any(" ".join(p.requested_assets), ["issuer key", "official registry", "full industry template", "patent files", "全部源码", "注册表签名", "认证私钥"])
    if not attribution_ok:
        risks.append("weak_or_missing_attribution_commitment")
    if exclusive:
        risks.append("exclusive_or_buyout_request")
    if asks_full_core:
        risks.append("requests_controlled_assets")
    if sensitive:
        risks.append("sensitive_data_context_requires_review")

    score = 0.28 + (0.22 if high_fit else 0.05) + (0.18 if attribution_ok else -0.05) + (0.12 if "paid" in budget or "budget" in budget or "pilot" in budget else 0.02) - (0.18 if exclusive else 0) - (0.16 if asks_full_core else 0) - (0.04 if sensitive else 0)
    score = clamp(score)

    if exclusive or asks_full_core:
        decision = "hold_for_originmoat_and_ip_review"
        next_step = "send sanitized public brief only; require MoU/NDA/attribution and exclude official registry keys/templates"
    elif score >= 0.70:
        decision = "invite_to_paid_discovery_or_pilot"
        next_step = "schedule 45-minute pilot scoping call and issue paid discovery SOW"
    elif score >= 0.50:
        decision = "accept_as_registered_partner_candidate_after_terms"
        next_step = "request attribution statement, pilot use case, and data boundary form"
    else:
        decision = "community_lead_or_monitor"
        next_step = "share public docs and keep in opportunity ledger"

    if sensitive:
        required_terms.append("privacy/data classification boundary and human review gate")
    return PartnerDecision(p.organization, decision, round(score, 4), risks, required_terms, next_step)


def assess_portfolio(portfolio: Portfolio) -> PortfolioAssessment:
    assessments = [assess_repo(r) for r in portfolio.repositories]
    lane_counts = Counter(a.lane for a in assessments)
    partner_decisions = [score_partner(p) for p in portfolio.partner_requests]
    if not assessments:
        portfolio_score = 0.0
    else:
        portfolio_score = sum(a.china_opportunity_score * 0.42 + a.commercialization_score * 0.38 + (1 - a.protection_need_score) * 0.10 + a.protection_need_score * 0.10 for a in assessments) / len(assessments)
    top_commercial = sorted(assessments, key=lambda x: x.commercialization_score, reverse=True)[:5]
    strategy = "build_china_official_registry_plus_paid_pilot_funnel"
    if any(a.lane == "china_industrial_ai" and a.commercialization_score > 0.75 for a in assessments):
        strategy = "prioritize_industrial_agent_and_trust_infrastructure_pilots_with_registry_protection"
    residuals = [
        "GitHub page view is a public snapshot; stars/followers and repository list may change.",
        "Economic benefit is not guaranteed; it depends on outreach, maintained docs, partner conversion, and official registry operation.",
        "Legal/IP conclusions require counsel; this system only prepares evidence and protection actions.",
    ]
    if top_commercial:
        residuals.append("Top commercialization candidates: " + ", ".join(a.name for a in top_commercial))
    return PortfolioAssessment(portfolio.owner, round(portfolio_score, 4), dict(lane_counts), strategy, assessments, partner_decisions, residuals)
