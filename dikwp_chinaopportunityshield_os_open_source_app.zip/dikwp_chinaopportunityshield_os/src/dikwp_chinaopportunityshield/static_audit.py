from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

BANNED = [
    "import requests", "from requests", "import socket", "import urllib", "from urllib",
    "import subprocess", "from subprocess", "os.system", "eval(", "exec(", "compile(",
    "webbrowser", "selenium", "playwright", "pyautogui", "paramiko", "ftplib", "smtplib",
    "token=", "api_key", "secret_key", "password=", "hidden telemetry", "auto complaint",
]


def audit_path(src: str | Path) -> Dict:
    root = Path(src)
    findings: List[Dict] = []
    for path in root.rglob("*.py"):
        if path.name == "static_audit.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for term in BANNED:
            if term in text:
                findings.append({"file": str(path), "term": term})
    return {
        "pass": not findings,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, credential capture, automatic complaints, or host mutation helpers in the offline core.",
    }


def write_audit(src: str | Path, out: str | Path) -> Dict:
    result = audit_path(src)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
