from __future__ import annotations

import argparse
from pathlib import Path

from .evaluator import load_portfolio, assess_portfolio, score_partner
from .models import PartnerRequest
from .reports import write_outputs, write_json
from .static_audit import write_audit


def cmd_analyze(args: argparse.Namespace) -> int:
    portfolio = load_portfolio(args.input)
    assessment = assess_portfolio(portfolio)
    write_outputs(Path(args.out), assessment)
    print(f"Wrote ChinaOpportunityShield outputs to {args.out}")
    return 0


def cmd_partner(args: argparse.Namespace) -> int:
    import json
    raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
    decisions = [score_partner(PartnerRequest(**p)) for p in raw.get("partner_requests", [])]
    write_json(Path(args.out), [d.__dict__ for d in decisions])
    print(f"Wrote partner screening to {args.out}")
    return 0


def cmd_static_audit(args: argparse.Namespace) -> int:
    result = write_audit(args.src, args.out)
    print(result)
    return 0 if result["pass"] else 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="oppshield", description="DIKWP ChinaOpportunityShield OS")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze", help="Analyze DIKWP GitHub portfolio and China-market opportunity shield plan")
    a.add_argument("input")
    a.add_argument("--out", default="outputs/demo")
    a.set_defaults(func=cmd_analyze)
    pa = sub.add_parser("partner", help="Screen partner requests")
    pa.add_argument("input")
    pa.add_argument("--out", default="outputs/demo/partner_screening_report.json")
    pa.set_defaults(func=cmd_partner)
    s = sub.add_parser("static-audit", help="Run offline static boundary audit")
    s.add_argument("src")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    s.set_defaults(func=cmd_static_audit)
    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
