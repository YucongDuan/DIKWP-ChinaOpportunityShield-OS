from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any


@dataclass
class Repository:
    name: str
    description: str = ""
    stars: int = 0
    updated: str = ""
    license: str = ""
    url: str = ""
    topics: List[str] = field(default_factory=list)


@dataclass
class PartnerRequest:
    organization: str
    sector: str
    stated_need: str
    requested_assets: List[str] = field(default_factory=list)
    requested_rights: List[str] = field(default_factory=list)
    attribution_commitment: str = "unknown"
    data_sensitivity: str = "unknown"
    budget_signal: str = "unknown"
    timeline: str = "unknown"


@dataclass
class Portfolio:
    owner: str
    profile_url: str
    snapshot_date: str
    repositories: List[Repository]
    partner_requests: List[PartnerRequest] = field(default_factory=list)


@dataclass
class RepoAssessment:
    name: str
    lane: str
    china_opportunity_score: float
    protection_need_score: float
    commercialization_score: float
    open_core_tier: str
    recommended_action: str
    evidence: List[str]
    residuals: List[str]


@dataclass
class PartnerDecision:
    organization: str
    decision: str
    score: float
    risks: List[str]
    required_terms: List[str]
    next_step: str


@dataclass
class PortfolioAssessment:
    owner: str
    portfolio_score: float
    top_lanes: Dict[str, int]
    recommended_strategy: str
    repo_assessments: List[RepoAssessment]
    partner_decisions: List[PartnerDecision]
    residuals: List[str]


def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
