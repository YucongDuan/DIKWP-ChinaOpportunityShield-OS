from __future__ import annotations

import json
import streamlit as st
from tempfile import NamedTemporaryFile
from pathlib import Path

from .evaluator import load_portfolio, assess_portfolio
from .reports import write_outputs

st.title("DIKWP ChinaOpportunityShield OS")
st.write("Upload a DIKWP GitHub portfolio manifest and generate a China-market opportunity and protection plan.")
file = st.file_uploader("Portfolio JSON", type=["json"])
if file:
    raw = file.getvalue().decode("utf-8")
    with NamedTemporaryFile("w", delete=False, suffix=".json", encoding="utf-8") as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    portfolio = load_portfolio(tmp_path)
    assessment = assess_portfolio(portfolio)
    st.metric("Portfolio Score", assessment.portfolio_score)
    st.json(json.loads(json.dumps(assessment, default=lambda o: o.__dict__, ensure_ascii=False)))
    out_dir = Path("outputs/app")
    write_outputs(out_dir, assessment)
    st.success(f"Outputs written to {out_dir}")
