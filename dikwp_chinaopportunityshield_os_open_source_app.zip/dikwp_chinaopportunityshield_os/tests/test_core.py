from pathlib import Path

from dikwp_chinaopportunityshield.evaluator import load_portfolio, assess_portfolio, classify_lane, assess_repo
from dikwp_chinaopportunityshield.models import Repository, PartnerRequest
from dikwp_chinaopportunityshield.evaluator import score_partner
from dikwp_chinaopportunityshield.static_audit import audit_path


def test_repo_classification():
    repo = Repository(name="DIKWP-ProofLedger-OS", description="claim-evidence verification ledger for RAG")
    assert classify_lane(repo) == "ai_trust_evidence"


def test_assessment_scores():
    portfolio = load_portfolio("examples/sample_yucongduan_portfolio.json")
    assessment = assess_portfolio(portfolio)
    assert assessment.portfolio_score > 0.5
    assert assessment.top_lanes
    assert any(r.name == "DIKWP-PilotFactory-OS" for r in assessment.repo_assessments)


def test_partner_blocking():
    p = PartnerRequest(
        organization="Copycat Inc",
        sector="manufacturing",
        stated_need="white label DIKWP gateway",
        requested_assets=["issuer key", "full industry template"],
        requested_rights=["exclusive", "source ownership"],
        attribution_commitment="unknown",
        data_sensitivity="critical",
        budget_signal="unclear",
    )
    d = score_partner(p)
    assert d.decision == "hold_for_originmoat_and_ip_review"
    assert "requests_controlled_assets" in d.risks


def test_static_audit_passes():
    result = audit_path("src")
    assert result["pass"] is True
