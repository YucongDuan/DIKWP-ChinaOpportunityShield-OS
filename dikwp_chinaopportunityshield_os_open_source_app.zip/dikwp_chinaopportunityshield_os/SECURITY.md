# Security Policy

The offline core should not include network clients, subprocess execution, dynamic code execution, hidden telemetry, credential capture, or automatic complaints.

Report security concerns through the project issue tracker after removing sensitive details.
