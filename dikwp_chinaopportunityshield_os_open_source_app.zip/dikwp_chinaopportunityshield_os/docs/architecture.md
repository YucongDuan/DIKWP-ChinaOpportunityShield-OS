# Architecture

```text
GitHub Portfolio Manifest
        |
        v
Repo Lane Classifier
        |
        +--> China Opportunity Score
        +--> Protection Need Score
        +--> Commercialization Score
        +--> Open-Core Tier
        |
        v
Partner Request Router
        |
        +--> Accept / Paid Pilot / Hold for Review / Monitor
        |
        v
Opportunity Ledger + Registry Seed
        |
        v
Protection Action Plan + 90-Day Launch Plan
```

The architecture follows DIKWP-Mesh 4.0 logic: noisy repository data is not treated as perfect. It is converted into anchors, lanes, opportunity scores, protection scores, residuals, and recovery actions.
