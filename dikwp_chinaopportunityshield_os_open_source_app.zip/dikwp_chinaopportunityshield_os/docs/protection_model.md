# Protection Model

## What should be open

- Reference code.
- Schemas.
- Demo data.
- Static audit tools.
- Example reports.
- Public conformance checklists.

## What should remain controlled

- Official registry issuer keys.
- Signed TrustPassport badge decisions.
- Full industry adapter packs.
- Enterprise deployment playbooks.
- Certification scoring rubrics.
- Partner contracts.
- Private pilot data.

## Why

Open-source value comes from adoption and trust. Economic value comes from official review, certification, registry, deployment support, and industry-specific adaptation.
