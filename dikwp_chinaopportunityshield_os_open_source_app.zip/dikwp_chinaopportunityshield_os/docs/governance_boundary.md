# Governance Boundary

The system supports opportunity protection, not aggressive suppression.

It must not be used to harass competitors, send automatic legal complaints, impersonate official government certification, scrape partner systems, or publish unverified accusations.

Signals are not legal conclusions. Partner risk is not guilt. Copycat pressure should first be converted into attribution, registration, or partnership unless there is clear evidence requiring legal review.
