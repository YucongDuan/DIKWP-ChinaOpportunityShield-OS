# China Market Opportunity Map

## Priority lanes

1. Industrial agent governance and AICAP-style access control.
2. Evidence ledger for RAG, AI reports, and enterprise knowledge bases.
3. Public-service AI pilots: transport, welfare, education, health navigation.
4. OpenClaw / DeepSeek user operation capsules for SMEs.
5. Academic and medical research evidence systems.
6. AI employment transition and capability commons.
7. IP, standardization, registry, and certification systems.

## Recommended first paid products

- DIKWP Paid Discovery Review.
- DIKWP TrustPassport Registry Candidate Review.
- DIKWP Evidence Ledger Pilot.
- DIKWP OpenClaw DeepSeek SME Training.
- DIKWP Public-Service SemanticClosure Pilot.
- DIKWP China AI Opportunity Shield Review.
