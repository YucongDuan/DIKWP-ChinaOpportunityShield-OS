# Roadmap

## v0.2
- Add GitHub API connector outside the offline core.
- Add TrustPassport seed export.
- Add GitHub Actions demo.

## v0.3
- Add China policy opportunity tags.
- Add sector-specific pilot templates.
- Add partner MOU template generator.

## v1.0
- Official DIKWP registry integration.
- Partner portal.
- Signed pilot review workflow.
