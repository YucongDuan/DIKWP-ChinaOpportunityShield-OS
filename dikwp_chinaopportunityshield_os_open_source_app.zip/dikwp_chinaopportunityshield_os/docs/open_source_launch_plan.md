# Open Source Launch Plan

1. Publish DIKWP ChinaOpportunityShield OS as a strategy/control-plane repository.
2. Add README, LICENSE, NOTICE, CITATION.cff, SECURITY, CONTRIBUTING, and example outputs.
3. Pin it alongside TrustPassport, OriginMoat, EcosystemRouter, PilotFactory, and SemanticClosure.
4. Publish a short Chinese article: "如何让 DIKWP 开源不被免费消耗，而转化为中国市场试点机会".
5. Use the outputs/demo directory as a public example for partners.
6. Add a partner intake form and pilot menu.
