# Partner Contract Clauses Draft

These are non-legal drafting prompts for counsel review.

1. Attribution: Partner shall preserve Yucong Duan / DIKWP attribution in public material, derivative documentation, and pilot reports.
2. Non-exclusive pilot: Unless separately agreed, pilot use is non-exclusive and does not transfer DIKWP intellectual property.
3. Controlled assets: Official registry keys, signed badge decisions, certification rubrics, and full industry adapter packs are not included in public open-source use.
4. Public claims: Partner may not claim official DIKWP certification without signed review.
5. Data boundary: Sensitive operational, medical, financial, or personal data must be handled under a separate data boundary and human review protocol.
6. Evidence ledger: Pilot meetings, materials, outputs, and attributions should be recorded in an opportunity ledger.
