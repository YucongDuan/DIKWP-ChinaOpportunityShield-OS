# Landing Page Copy

## DIKWP ChinaOpportunityShield OS

Turn a public DIKWP GitHub portfolio into a protected China-market opportunity engine.

Analyze projects. Route partners. Preserve attribution. Protect official value layers. Convert open-source attention into pilots, reviews, registry, certification, and training.

### For

- DIKWP maintainers
- enterprise pilot teams
- integrators
- universities
- public-service AI partners
- China AI+ industry pilots

### Output

- repository lane map
- China opportunity matrix
- partner screening report
- registry seed
- opportunity ledger
- 90-day action plan
