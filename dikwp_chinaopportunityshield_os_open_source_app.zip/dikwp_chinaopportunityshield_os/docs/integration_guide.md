# Integration Guide

## With TrustPassport OS
Use official_registry_seed.json as the initial candidate list.

## With OriginMoat OS
Use open_core_release_policy.csv to decide what to open and what to keep controlled.

## With EcosystemRouter OS
Use partner_screening_report.json to route partners into registered partner candidates.

## With PilotFactory OS
Use benefit_capture_brief.md and priority_90_day_action_plan.md to move leads into paid discovery.

## With IPGuardian OS
Route exclusive-rights, buyout, no-attribution, and controlled-asset requests into IP review.
