# Contributing

Contributions are welcome if they preserve DIKWP attribution, evidence boundaries, and non-misleading claims.

Please do not submit code that adds network access, credential capture, hidden telemetry, partner scraping, automatic legal claims, or unauthorized monitoring.
