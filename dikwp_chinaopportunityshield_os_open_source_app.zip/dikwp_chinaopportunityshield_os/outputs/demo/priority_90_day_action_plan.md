# DIKWP ChinaOpportunityShield 90-Day Action Plan

## Week 1-2: Clean Public Surface
- Select flagship repos: ProofLedger, OpenClaw, SemanticClosure, TaskRide, BusPulse/TransitVoice, ScholarTruth, TrustPassport.
- Ensure README / LICENSE / NOTICE / CITATION.cff / SECURITY are present.
- Add project one-liner, action boundary, quick start, demo outputs, and Chinese product brief.

## Week 3-4: Launch China Pilot Menu
- Publish 5 pilot packages: AI evidence ledger, public transport service closure, enterprise agent audit, DeepSeek OpenClaw, academic integrity triage.
- Each pilot has scope, inputs, outputs, timeline, price band, and non-claim boundary.

## Month 2: Convert Leads
- Use PilotFactory logic: inbound lead -> opportunity ledger -> paid discovery -> pilot SOW -> official review report.
- Use TrustPassport for registry candidate IDs.
- Use IPGuardian for copycat / no-attribution monitoring.

## Month 3: Public Credibility
- Publish 2 anonymized case studies.
- Publish DIKWP China TrustOS map.
- Invite universities / associations / integrators as registered partner candidates.
- Keep industry templates, signed badges, and official reviews as value layers.