# DIKWP ChinaOpportunityShield Protection Action Plan

Owner: **YucongDuan / DIKWP**
Portfolio score: **0.6244**
Recommended strategy: **prioritize_industrial_agent_and_trust_infrastructure_pilots_with_registry_protection**

## 1. Strategic Diagnosis

The portfolio already contains many DIKWP application prototypes. The immediate risk is not absence of projects but **opportunity leakage**: external organizations can reuse repository ideas, remove attribution, request private templates, or turn public reference code into commercial packaging without returning value to the originator.

The protection strategy is therefore not code secrecy. It is **registry-led open source**: open enough to attract pilots, but keep official review, signed badges, industry adapter packs, certification, and pilot reports as controlled value layers.

## 2. Mandatory Protection Moves

1. Every active DIKWP repository should contain README, LICENSE, NOTICE, CITATION.cff, SECURITY, and TrustPassport metadata.
2. Each public pilot conversation should enter an Opportunity Ledger before materials are shared.
3. Private assets must be classified: issuer keys, official registry decisions, full industry templates, enterprise deployment playbooks, and partner contracts are controlled assets.
4. Public deliverables should be reference implementations, schemas, demos, sample data, tests, and open evaluation logic.
5. Paid layers should be official DIKWP review, China pilot scoping, industry adaptation, training certification, and signed registry badge issuance.

## 3. Priority Repositories

- **DIKWP-BusPulse-OS** — lane: `china_industrial_ai`, commercialization: `0.7639`, protection need: `0.7292`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-StandardForge-OS** — lane: `ip_standardization`, commercialization: `0.761`, protection need: `0.794`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-TRIZ-Forge-OS** — lane: `ip_standardization`, commercialization: `0.761`, protection need: `0.794`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-TaskRide-OS** — lane: `commercial_conversion`, commercialization: `0.7588`, protection need: `0.7436`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-IPGuardian-OS** — lane: `ip_standardization`, commercialization: `0.717`, protection need: `0.794`, action: `keep_as_ecosystem_supporting_project`
- **DIKWP-PilotFactory-OS** — lane: `commercial_conversion`, commercialization: `0.7148`, protection need: `0.7436`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-TruthSnap-OS** — lane: `ai_trust_evidence`, commercialization: `0.7057`, protection need: `0.5772`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-ScholarTruth-OS** — lane: `ai_trust_evidence`, commercialization: `0.7057`, protection need: `0.5772`, action: `publish_with_case_study_and_partner_call`
- **DIKWP-WorkBridge-OS** — lane: `ai_trust_evidence`, commercialization: `0.6617`, protection need: `0.5772`, action: `keep_as_ecosystem_supporting_project`
- **DIKWP-IntentEconomy-OS** — lane: `ai_trust_evidence`, commercialization: `0.6617`, protection need: `0.5772`, action: `keep_as_ecosystem_supporting_project`
- **DIKWP-QuantLedger-OS** — lane: `ai_trust_evidence`, commercialization: `0.6617`, protection need: `0.5772`, action: `keep_as_ecosystem_supporting_project`
- **DIKWP-TrustPassport-OS** — lane: `ai_trust_evidence`, commercialization: `0.6617`, protection need: `0.5772`, action: `keep_as_ecosystem_supporting_project`

## 4. Partner Handling Rules

- Do not send full source, private templates, official registry files, or issuer keys before attribution and scope terms are written.
- For government, transport, manufacturing, medical, education, and finance opportunities, start with a paid discovery or low-risk offline pilot.
- Copycat-like actors should first receive public docs and a partner conversion path, not escalation language.
- If a partner requests exclusive rights, patent transfer, or full source ownership, route to OriginMoat/IPGuardian review before any technical sharing.

## 5. 30/60/90-Day Actions

### 30 days
- Pick 6 public flagship repos and standardize READMEs, badges, quick-start demos, and Mandarin product briefs.
- Publish a DIKWP China Pilot Menu that routes enterprises to 5 paid pilot types.
- Create a public registry seed: project name, claim boundary, owner attribution, status, and official review pathway.

### 60 days
- Run 3 small offline pilots: transport/service, enterprise evidence ledger, and public-benefit AI governance.
- Add signed pilot report templates and partner intake forms.
- Invite integrators as registered partner candidates rather than giving them unbounded reuse rights.

### 90 days
- Launch official DIKWP TrustPassport China Registry v0.1.
- Release training certification syllabus: DIKWP Pilot Analyst, DIKWP Evidence Steward, DIKWP OpenClaw Operator.
- Publish anonymized case reports and collect inbound paid pilot leads.

## 6. Kill / Recovery

Kill conditions: missing attribution, partner demands exclusive rights, hidden commercial packaging, official certification claims without review, private templates requested before agreement, or sensitive data exposure.

Recovery: downgrade sharing to public brief, require attribution clause, create opportunity ledger entry, route to paid discovery, and preserve official registry/certification as controlled value layer.