# Code of Conduct

Use this project to improve attribution, transparent collaboration, pilot routing, and responsible ecosystem growth. Do not use it to harass competitors, create false claims, or suppress legitimate academic use and fair discussion.
